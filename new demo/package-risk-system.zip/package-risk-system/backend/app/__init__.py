"""Package Risk research application."""
